package org.acme.repostiory

import jakarta.enterprise.context.ApplicationScoped
import org.acme.body.ProductBody
import org.acme.dto.response.OrderResponse
import org.acme.dto.response.ProductResponse
import org.acme.gen.Tables.ORDER
import org.acme.gen.Tables.PRODUCTS
import org.acme.generateTSID
import org.jooq.DSLContext
import org.jooq.impl.DSL
import java.time.LocalDateTime

@ApplicationScoped
class ProductRepository(
    private val jooq: DSLContext
) {

    fun create(body: ProductBody): String =
        jooq.newRecord(PRODUCTS, body)
            .also { product ->
                product.productId = generateTSID()
                product.createdAt = LocalDateTime.now()
                product.updatedAt = LocalDateTime.now()
                product.store()
            }
            .productId

    fun update(body: ProductBody, productId: String): String =
        (jooq.fetchOne(PRODUCTS, PRODUCTS.PRODUCT_ID.eq(productId))
            ?: throw RuntimeException("Product with id $productId not found"))
            .also {
                it.name = body.name
                it.price = body.price
                it.updatedAt = LocalDateTime.now()
                it.store()
            }
            .productId

    fun getById(productId: String) =
        jooq.select(
            PRODUCTS.PRODUCT_ID,
            PRODUCTS.NAME,
            PRODUCTS.PRICE,
            PRODUCTS.CREATED_AT.`as`("insertAt")
        )
        .from(PRODUCTS)
        .where(PRODUCTS.PRODUCT_ID.eq(productId))
        .and(PRODUCTS.DELETED_AT.isNull)
        .limit(1)
        .fetchOneInto(ProductResponse::class.java)
        ?: throw RuntimeException("Product with id $productId not found")

    fun getAll(name: String?, price: Double?): MutableList<ProductResponse> =
        jooq.selectFrom(PRODUCTS)
            .where(PRODUCTS.DELETED_AT.isNull)
            .apply {
                // make if biasa
                if (name != null) {
                    and(PRODUCTS.NAME.like("%$name%"))
                }
                // fungsi bawaan kotlin untuk cek nullabel
                price?.let {
                    and(PRODUCTS.PRICE.greaterThan(price))
                }
            }
            .orderBy(PRODUCTS.CREATED_AT.desc())
            .fetchInto(ProductResponse::class.java)

    fun softDelete(productId: String) =
        jooq.update(PRODUCTS)
            .set(PRODUCTS.DELETED_AT, LocalDateTime.now())
            .where(PRODUCTS.PRODUCT_ID.eq(productId))
            .execute()

    // join otomatis
    fun getOrder(): MutableList<OrderResponse> =
        jooq.select(
            ORDER.ORDER_ID,
            DSL.row(
                ORDER.products().PRODUCT_ID,
                ORDER.products().NAME,
                ORDER.products().PRICE
            ).mapping(::ProductResponse).`as`("product"),
            ORDER.QTY,
            ORDER.PRICE,
            ORDER.TOTAL
        )
        .from(ORDER)
        .where(ORDER.DELETED_AT.isNull)
        .fetchInto(OrderResponse::class.java)

    // join manual
    fun getOrderWithJoin(): MutableList<OrderResponse> =
        jooq.select(
            ORDER.ORDER_ID,
            DSL.row(
                PRODUCTS.PRODUCT_ID,
                PRODUCTS.NAME,
                PRODUCTS.PRICE
            ).mapping(::ProductResponse).`as`("product"),
            ORDER.QTY,
            ORDER.PRICE,
            ORDER.TOTAL
        )
        .from(ORDER)
        .join(PRODUCTS).on(PRODUCTS.PRODUCT_ID.eq(ORDER.PRODUCT_ID))
        .where(ORDER.DELETED_AT.isNull)
        .fetchInto(OrderResponse::class.java)

    fun countProduct() =
        jooq.fetchCount(PRODUCTS, PRODUCTS.DELETED_AT.isNull)

    fun isExists(productId: String) =
        jooq.fetchExists(PRODUCTS, PRODUCTS.PRODUCT_ID.eq(productId))

}