package org.acme.controller

import jakarta.transaction.Transactional
import jakarta.validation.Valid
import jakarta.ws.rs.DELETE
import jakarta.ws.rs.GET
import jakarta.ws.rs.POST
import jakarta.ws.rs.PUT
import jakarta.ws.rs.Path
import org.acme.body.ProductBody
import org.acme.dto.response.BaseResponse
import org.acme.repostiory.ProductRepository
import org.jboss.resteasy.reactive.RestPath

@Path("/api/v1/products")
class ProductController(
    private val productRepository: ProductRepository
) {

    @POST
    @Transactional
    fun create(@Valid body: ProductBody): BaseResponse {
        val productId = productRepository.create(body)
        return BaseResponse(
            message = "Product created",
            data = productId
        )
    }

    @PUT
    @Transactional
    @Path("/{productId}")
    fun update(@RestPath productId: String, @Valid body: ProductBody): BaseResponse {
        productRepository.update(body, productId)
        return BaseResponse(
            message = "Product updated",
            data = productId
        )
    }

    @GET
    @Path("/{productId}")
    fun getById(@RestPath productId: String) =
        productRepository.getById(productId)

    @GET
    fun getAll() = productRepository.getAll("", 0.0)

    @DELETE
    @Path("/{productId}")
    @Transactional
    fun delete(@RestPath productId: String): BaseResponse {
        productRepository.softDelete(productId)
        return BaseResponse(
            message = "Product deleted",
            data = null
        )
    }

    @GET
    @Path("/order")
    fun getOder() =
        productRepository.getOrder()

}