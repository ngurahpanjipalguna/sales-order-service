package org.acme.dto.response

data class ProductResponse(
    val productId: String,
    val name: String,
    val price: Double
)
