package org.acme.dto.response

data class OrderResponse(
    val orderId:String,
    val product: ProductResponse,
    val qty: Int,
    val price: Double,
    val total: Double
)
