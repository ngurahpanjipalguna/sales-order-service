package org.acme.body

import jakarta.validation.constraints.NotNull

data class ProductBody(
    @field:NotNull
    val name: String?,

    @field:NotNull
    val price: Double?
)
