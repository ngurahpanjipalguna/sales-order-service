create table products
(
    product_id VARCHAR(13) not null primary key,
    name varchar(255) not null,
    price double null default 0,
    created_at datetime null default current_timestamp,
    updated_at datetime null default current_timestamp,
    deleted_at datetime null
)