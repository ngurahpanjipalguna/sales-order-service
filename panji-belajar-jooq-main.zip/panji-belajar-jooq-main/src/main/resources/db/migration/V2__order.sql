create table `order`
(
    order_id varchar(13) not null primary key,
    product_id varchar(13) not null,
    qty integer not null,
    price double not null,
    total double not null,
    created_at datetime null  default current_timestamp,
    updated_at datetime null default current_timestamp,
    deleted_at datetime null,
    constraint product_order_fk foreign key (product_id) references products(product_id)
)