/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.posmicro.customer.servlet;

/**
 *
 * @author ktanjana
 */
import com.fasterxml.jackson.databind.ObjectMapper;
import com.posmicro.customer.entity.Customer;
import com.posmicro.customer.util.ResponseCustomerService;
import com.posmicro.util.AppConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.util.regex.Pattern;

@WebServlet(name = "CustomerEditServlet", urlPatterns = {"/CustomerEditServlet"})
public class CustomerEditServlet extends HttpServlet {

    private static final String API_URL = AppConfig.getAPI_URL_CUSTOMER();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        Long id = Long.valueOf(req.getParameter("customerId"));
        URL url = new URL(API_URL + "/get/" + id);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestProperty("Accept", "application/json");

        if (conn.getResponseCode() == 200) {
            Customer customer = new ObjectMapper().readValue(conn.getInputStream(), Customer.class);
            req.setAttribute("customer", customer);
        } else {
            req.setAttribute("error", "Load failed: " + conn.getResponseCode());
        }

        conn.disconnect();
        req.getRequestDispatcher("/customer-edit.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String action = req.getParameter("action");
        Long customerId = Long.valueOf(req.getParameter("customerId"));

        if ("delete".equalsIgnoreCase(action)) {
            handleDelete(req, resp, customerId);
            return;
        }

        Customer customer = new Customer();
        customer.setCustomerId(customerId);
        customer.setName(req.getParameter("name"));
        customer.setEmail(req.getParameter("email"));
        customer.setPhone(req.getParameter("phone"));

        // Normalize number formatting for numeric fields
        String thousandSeparator = req.getParameter("thousandSeparator");
        String decimalSeparator = req.getParameter("decimalSeparator");

        if (thousandSeparator == null || thousandSeparator.length() < 1 || decimalSeparator == null || decimalSeparator.length() < 1) {
            NumberFormat nf = NumberFormat.getNumberInstance();
            nf.setMaximumFractionDigits(2);
            nf.setMinimumFractionDigits(0);
            char thousandSep = ',';  // sensible defaults in case nf isn't a DecimalFormat
            char decimalSep = '.';
            if (nf instanceof DecimalFormat) {
                DecimalFormatSymbols symbols = ((DecimalFormat) nf).getDecimalFormatSymbols();
                thousandSep = symbols.getGroupingSeparator();
                decimalSep = symbols.getDecimalSeparator();
            }
            thousandSeparator = Character.toString(thousandSep);
            decimalSeparator = Character.toString(decimalSep);
            
        }

        String incomeStr = normalizeNumber(req.getParameter("income"), thousandSeparator, decimalSeparator);
        String ageStr = normalizeNumber(req.getParameter("age"), thousandSeparator, decimalSeparator);
        String pointsStr = normalizeNumber(req.getParameter("loyaltyPoints"), thousandSeparator, decimalSeparator);

        Integer iIncome = 0;
        Integer iAge = 0;
        Integer iPonts = 0;
        try {
            iIncome = Integer.parseInt(incomeStr);
            iAge = Integer.parseInt(ageStr);
            iPonts = Integer.parseInt(pointsStr);
        } catch (Exception exc) {
            req.setAttribute("message", "Failed to convert numbers: " + exc.toString());
            req.getRequestDispatcher("customer-edit.jsp").forward(req, resp);
        }

        customer.setIncome(iIncome);
        customer.setAge(iAge);
        customer.setLoyaltyPoints(iPonts);
        customer.setMarriedStatus(Boolean.valueOf(req.getParameter("marriedStatus")));
        customer.setTenantId(1L);

        ObjectMapper mapper = new ObjectMapper();
        String json = mapper.writeValueAsString(customer);

        try {
            URL url = new URL(API_URL + "/" + customerId);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("PUT");
            conn.setRequestProperty("Content-Type", "application/json");

            OutputStream os = conn.getOutputStream();
            os.write(json.getBytes());
            os.flush();

            if (conn.getResponseCode() == 200) {
                ResponseCustomerService result = mapper.readValue(conn.getInputStream(), ResponseCustomerService.class);
                req.setAttribute("message", "Customer updated successfully with ID: " + result.getCustomerId());
            } else {
                req.setAttribute("error", "Failed to update customer.");
            }

            conn.disconnect();
        } catch (Exception e) {
            req.setAttribute("error", "Error: " + e.getMessage());
        }

        req.getRequestDispatcher("customer-edit.jsp").forward(req, resp);
    }

    private void handleDelete(HttpServletRequest req, HttpServletResponse resp, Long customerId)
            throws ServletException, IOException {
        try {
            URL url = new URL(API_URL + "/" + customerId);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("DELETE");

            if (conn.getResponseCode() == 200) {
                resp.sendRedirect("CustomerListServlet?message=Customer+with+ID+" + customerId + "+deleted+successfully");
            } else {
                req.setAttribute("error", "Failed to delete customer.");
                req.getRequestDispatcher("customer-edit.jsp").forward(req, resp);
            }

            conn.disconnect();
        } catch (Exception e) {
            req.setAttribute("error", "Error: " + e.getMessage());
            req.getRequestDispatcher("customer-edit.jsp").forward(req, resp);
        }
    }

    private String normalizeNumberX(String input, String thousandSeparator, String decimalSeparator) {
        if (input == null) {
            return "0";
        }
        String normalized = input;
        if (thousandSeparator != null && !thousandSeparator.equals("")) {
            normalized = normalized.replace(thousandSeparator, "");
        }
        if (decimalSeparator != null && !decimalSeparator.equals(".")) {
            normalized = normalized.replace(decimalSeparator, ".");
        }
        return normalized;
    }

    private String normalizeNumber(String input,
            String thousandSeparator,
            String decimalSeparator) {
        if (input == null || input.isBlank()) {
            return "0";
        }

        // 1) Trim
        String s = input.trim();

        // 2) Strip *all* grouping separators
        if (thousandSeparator != null && !thousandSeparator.isEmpty()) {
            s = s.replaceAll(Pattern.quote(thousandSeparator), "");
        }

        // 3) Replace the true decimal separator with “.”
        //    (only if it isn’t already “.”)
        if (decimalSeparator != null
                && !decimalSeparator.equals(".")
                && !decimalSeparator.isEmpty()) {
            s = s.replaceAll(Pattern.quote(decimalSeparator), ".");
        }

        // 4) If it now starts with “.”, prefix a zero
        if (s.startsWith(".")) {
            s = "0" + s;
        }
        // 5) If it ends with “.”, drop it
        if (s.endsWith(".")) {
            s = s.substring(0, s.length() - 1);
        }

        return s;
    }
}
