/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.posmicro.customer.servlet;

/**
 *
 * @author ktanjana
 */


import com.fasterxml.jackson.databind.ObjectMapper;
import com.posmicro.customer.entity.Customer;
import com.posmicro.customer.util.ResponseCustomerService;
import com.posmicro.util.AppConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

@WebServlet(name = "CustomerAddServlet", urlPatterns = {"/CustomerAddServlet"})
public class CustomerAddServlet extends HttpServlet {
    private static String API_URL = AppConfig.getAPI_URL_CUSTOMER();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        // read form
        String name = req.getParameter("name");
        String email = req.getParameter("email");
        String phone = req.getParameter("phone");
        Integer income = Integer.valueOf(req.getParameter("income"));
        Integer age = Integer.valueOf(req.getParameter("age"));
        Boolean married = Boolean.valueOf(req.getParameter("marriedStatus"));
        Integer points = Integer.valueOf(req.getParameter("loyaltyPoints"));

        Customer c = new Customer();
        c.setName(name);
        c.setEmail(email);
        c.setPhone(phone);
        c.setIncome(income);
        c.setAge(age);
        c.setMarriedStatus(married);
        c.setLoyaltyPoints(points);
        c.setTenantId(1L);

        ObjectMapper mapper = new ObjectMapper();
        String json = mapper.writeValueAsString(c);

        try {
            URL url = new URL(API_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");

            OutputStream os = conn.getOutputStream(); os.write(json.getBytes()); os.flush();

            if (conn.getResponseCode() != 200) {
                req.setAttribute("error", "Failed to create customer: HTTP " + conn.getResponseCode());
            } else {
                // read id back
                ResponseCustomerService result = mapper.readValue(conn.getInputStream(), ResponseCustomerService.class);
                req.setAttribute("message", "Customer created (ID: " + result.getCustomerId() + ")");
            }
            conn.disconnect();
        } catch (Exception e) {
            req.setAttribute("error", "Error: " + e.getMessage());
        }
        req.getRequestDispatcher("/customer-add.jsp").forward(req, resp);
    }
}