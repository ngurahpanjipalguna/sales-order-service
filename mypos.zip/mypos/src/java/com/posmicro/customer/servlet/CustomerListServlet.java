/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.posmicro.customer.servlet;

/**
 *
 * @author ktanjana
 */


import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.posmicro.customer.entity.Customer;
import com.posmicro.util.AppConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

@WebServlet(name = "CustomerListServlet", urlPatterns = {"/CustomerListServlet"})
public class CustomerListServlet extends HttpServlet {
    private static  String API_ALL = AppConfig.getAPI_URL_CUSTOMER() + "/list/all";
    private static  String API_FIND = AppConfig.getAPI_URL_CUSTOMER() + "/find/";
private static String API_URL = AppConfig.getAPI_URL_CUSTOMER();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String search = req.getParameter("search");
        String apiUrl = (search != null && !search.isEmpty())
            ? API_FIND + URLEncoder.encode(search, StandardCharsets.UTF_8)
            : API_ALL;

        URL url = new URL(apiUrl);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Accept", "application/json");

        if (conn.getResponseCode() != 200) {
            req.setAttribute("error", "Failed to load customers: HTTP " + conn.getResponseCode());
            req.getRequestDispatcher("/customer-list.jsp").forward(req, resp);
            return;
        }

        ObjectMapper mapper = new ObjectMapper();
        List<Customer> list = mapper.readValue(
            new InputStreamReader(conn.getInputStream()),
            new TypeReference<List<Customer>>() {}
        );
        conn.disconnect();

        req.setAttribute("customers", list);
        req.getRequestDispatcher("/customer-list.jsp").forward(req, resp);
    }
}