/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.posmicro.customer.util;

import com.posmicro.product.util.*;

/**
 *
 * @author ktanjana
 */
public class ResponseCustomerService {
    private Long customerId;
    private String message; // may add next dev
    private Integer responseCode; // may add next dev

    /**
     * @return the productId
     */
    public Long getCustomerId() {
        return customerId;
    }

    /**
     * @param productId the productId to set
     */
    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * @return the responseCode
     */
    public Integer getResponseCode() {
        return responseCode;
    }

    /**
     * @param responseCode the responseCode to set
     */
    public void setResponseCode(Integer responseCode) {
        this.responseCode = responseCode;
    }
    
}
