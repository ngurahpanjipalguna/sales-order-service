/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.posmicro.util;

/**
 *
 * @author ktanjana
 */
public class AppConfig {

    /**
     * @return the DEFAULT_THRESHOLD_
     */
    public static float getDEFAULT_THRESHOLD_() {
        return DEFAULT_THRESHOLD_;
    }

    /**
     * @param aDEFAULT_THRESHOLD_ the DEFAULT_THRESHOLD_ to set
     */
    public static void setDEFAULT_THRESHOLD_(float aDEFAULT_THRESHOLD_) {
        DEFAULT_THRESHOLD_ = aDEFAULT_THRESHOLD_;
    }

    /**
     * @return the API_URL_PRODUCT_SUGGESTION
     */
    public static String getAPI_URL_PRODUCT_SUGGESTION() {
        return API_URL_PRODUCT_SUGGESTION;
    }
    
     private static  String API_URL_PRODUCT = "http://localhost:8081/api/v1/protect/product";
     private static  String API_URL_PRODUCT_SUGGESTION = "http://localhost:8081/api/v1/protect/product_suggestion";
     private static  String API_URL_CUSTOMER = "http://localhost:8082/api/v1/protect/customer";  
     private static  String API_URL_SALES_ORDER = "http://localhost:8083/api/v1/protect/sales-order";
     private static  String API_URL_ORDER_ITEM   = "http://localhost:8083/api/v1/protect/order-item";
     private static float  DEFAULT_THRESHOLD_ = 0.2f;

    /**
     * @return the API_URL_PRODUCT
     */
    public static String getAPI_URL_PRODUCT() {
        return API_URL_PRODUCT;
    }

    /**
     * @return the API_URL_CUSTOMER
     */
    public static String getAPI_URL_CUSTOMER() {
        return API_URL_CUSTOMER;
    }

    /**
     * @return the API_URL_SALES_ORDER
     */
    public static String getAPI_URL_SALES_ORDER() {
        return API_URL_SALES_ORDER;
    }
    public static String getAPI_URL_ORDER_ITEM()  { 
        return API_URL_ORDER_ITEM; 
    }
    
}
