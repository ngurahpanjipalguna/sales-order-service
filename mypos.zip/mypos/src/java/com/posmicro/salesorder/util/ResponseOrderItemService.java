/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.posmicro.salesorder.util;

/**
 *
 * @author ktanjana
 */
public class ResponseOrderItemService {
    private Long salesOrderId;
    private String message; // may add next dev
    private Integer responseCode; // may add next dev
}
