/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.posmicro.salesorder.util;

/**
 *
 * @author ktanjana
 */
public interface SalesOrderStatus {
    public final static String SALES_ORDER_STATUS_DRAFT ="DRAFT";
    public final static String SALES_ORDER_STATUS_FINAL ="FINAL"; 
    public final static String SALES_ORDER_STATUS_CANCEL ="CANCEL"; 
}
