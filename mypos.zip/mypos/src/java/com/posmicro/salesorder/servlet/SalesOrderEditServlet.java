/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.posmicro.salesorder.servlet;

/**
 *
 * @author ktanjana
 */
import com.fasterxml.jackson.databind.ObjectMapper;
import com.posmicro.salesorder.entity.SalesOrder;
import com.posmicro.salesorder.util.ResponseSalesOrderService;
import com.posmicro.util.AppConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;

@WebServlet(name = "SalesOrderEditServlet", urlPatterns = {"/SalesOrderEditServlet"})
public class SalesOrderEditServlet extends HttpServlet {

    private static final String API_URL = AppConfig.getAPI_URL_SALES_ORDER();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        Long id = Long.valueOf(req.getParameter("orderId"));
        URL url = new URL(API_URL + "/get/" + id);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestProperty("Accept", "application/json");

        if (conn.getResponseCode() == 200) {
            SalesOrder salesOder = new ObjectMapper()
                    .readValue(conn.getInputStream(), SalesOrder.class);
            if (salesOder != null) {
                req.setAttribute("order", salesOder);
            }
        } else {
            req.setAttribute("error", "Load failed: " + conn.getResponseCode());
        }
        conn.disconnect();
        req.getRequestDispatcher("/salesorder-edit.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String action = req.getParameter("action");
        Long id = Long.valueOf(req.getParameter("orderId"));

        if ("delete".equalsIgnoreCase(action)) {
            handleDelete(req, resp, id);
            return;
        }

        SalesOrder o = new SalesOrder();
        o.setOrderId(id);
        o.setCustomerId(Long.parseLong(req.getParameter("customerId")));
        o.setCustomerName(req.getParameter("customerName"));
        // normalize totalAmount
        String ds = req.getParameter("decimalSeparator"),
                ts = req.getParameter("thousandSeparator");

        if (ts == null || ts.length() < 1 || ds == null || ds.length() < 1) {
            // 1) Create a NumberFormat for the user's locale
            NumberFormat nf = NumberFormat.getNumberInstance();
            nf.setMaximumFractionDigits(2);
            nf.setMinimumFractionDigits(0);

            // 2) Extract the grouping (thousands) and decimal separators
            char thousandSep = ',';  // sensible defaults in case nf isn't a DecimalFormat
            char decimalSep = '.';
            if (nf instanceof DecimalFormat) {
                DecimalFormatSymbols symbols = ((DecimalFormat) nf).getDecimalFormatSymbols();
                thousandSep = symbols.getGroupingSeparator();
                decimalSep = symbols.getDecimalSeparator();
            }

            // 3) Convert those chars to Strings
            ts = String.valueOf(thousandSep);
            ds = String.valueOf(decimalSep);
        }

        String amt = req.getParameter("totalAmount")
                .replace(ts, "").replace(ds, ".");
        try{
            o.setTotalAmount(Double.parseDouble(amt));
        }catch(Exception exc){
            
        }
        o.setStatus(req.getParameter("status"));
        o.setTenantId(1L);

        ObjectMapper m = new ObjectMapper();
        String json = m.writeValueAsString(o);
        req.setAttribute("orderId", ""+id);
        
        try {
            URL url = new URL(API_URL + "/" + id);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("PUT");
            conn.setRequestProperty("Content-Type", "application/json");
            OutputStream os = conn.getOutputStream();
            os.write(json.getBytes());
            os.flush();

            if (conn.getResponseCode() == 200) {
                ResponseSalesOrderService r = m.readValue(
                        conn.getInputStream(), ResponseSalesOrderService.class);
                req.setAttribute("message", "Order updated—ID: " + r.getSalesOrderId());
            } else {
                req.setAttribute("error", "Update failed: " + conn.getResponseCode());
            }
            conn.disconnect();
            
        } catch (Exception e) {
            req.setAttribute("error", "Error: " + e.getMessage());
        }
        
        req.getRequestDispatcher("/salesorder-edit.jsp").forward(req, resp);
    }

    private void handleDelete(HttpServletRequest req, HttpServletResponse resp, Long id)
            throws ServletException, IOException {
        try {
            URL url = new URL(API_URL + "/" + id);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("DELETE");
            if (conn.getResponseCode() == 200) {
                resp.sendRedirect("SalesOrderListServlet?message=Order+ID+" + id + "+deleted");
                return;
            } else {
                req.setAttribute("error", "Delete failed: " + conn.getResponseCode());
            }
            conn.disconnect();
        } catch (Exception e) {
            req.setAttribute("error", "Error: " + e.getMessage());
        }
        req.getRequestDispatcher("/salesorder-edit.jsp").forward(req, resp);
    }
}
