/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.posmicro.salesorder.servlet;

/**
 *
 * @author ktanjana
 */
import com.fasterxml.jackson.databind.ObjectMapper;
import com.posmicro.salesorder.entity.OrderItem;
import com.posmicro.salesorder.util.ResponseSalesOrderService;
import com.posmicro.util.AppConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

@WebServlet(name = "OrderItemEditServlet", urlPatterns = {"/OrderItemEditServlet"})
public class OrderItemEditServlet extends HttpServlet {

    private static final String API_URL = AppConfig.getAPI_URL_ORDER_ITEM();
    private static final String SALES_URL = AppConfig.getAPI_URL_SALES_ORDER();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        Long detailId = Long.valueOf(req.getParameter("orderDetailId"));
        Long orderId = Long.valueOf(req.getParameter("orderId"));
        // fetch single item
        URL url = new URL(API_URL + "/get/" + detailId);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestProperty("Accept", "application/json");
        if (c.getResponseCode() == 200) {
            OrderItem it = new ObjectMapper()
                    .readValue(c.getInputStream(), OrderItem.class);
            req.setAttribute("item", it);
        } else {
            req.setAttribute("error", "Load failed: " + c.getResponseCode());
        }
        c.disconnect();
        req.getRequestDispatcher("/orderitem-edit.jsp?orderId=" + orderId).forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String action = req.getParameter("action");

        Long detailId = Long.valueOf(req.getParameter("orderDetailId"));
        Long orderId = Long.valueOf(req.getParameter("orderId"));

        if ("delete".equalsIgnoreCase(action)) {
            // delete
            URL url = new URL(API_URL + "/" + detailId);
            HttpURLConnection c = (HttpURLConnection) url.openConnection();
            c.setRequestMethod("DELETE");
            if (c.getResponseCode() == 200) {
                resp.sendRedirect("OrderItemListServlet?orderId=" + orderId + "&message=Item+deleted");
                return;
            } else {
                req.setAttribute("error", "Delete failed: " + c.getResponseCode());
            }
            c.disconnect();
        } else {
            OrderItem it = new OrderItem();
            it.setOrderDetailId(detailId);
            // parent id
            // skip setting salesOrder object here unless API requires
            it.setProductId(Long.valueOf(req.getParameter("productId")));
            it.setProductName(req.getParameter("productName"));
            it.setProductCategory(req.getParameter("productCategory"));

            String decimalSeparator = req.getParameter("decimalSeparator");
            String thousandSeparator = req.getParameter("thousandSeparator");

            if (decimalSeparator == null || decimalSeparator.length() < 1) {
                decimalSeparator = ",";
            }
            if (thousandSeparator == null || thousandSeparator.length() < 1) {
                thousandSeparator = ".";
            }

            String qty = req.getParameter("salesQuantity").replace(thousandSeparator, "");//.replace(ds, ".");
            String pr = req.getParameter("salesPrice").replace(thousandSeparator, "");//.replace(ds, ".");
            it.setSalesQuantity(Float.parseFloat(qty));
            it.setSalesPrice(Float.parseFloat(pr));
            it.setTenantId(1L);

            ObjectMapper m = new ObjectMapper();
            String json = m.writeValueAsString(it);

            URL url = new URL(API_URL + "/" + detailId);
            HttpURLConnection c = (HttpURLConnection) url.openConnection();
            c.setDoOutput(true);
            c.setRequestMethod("PUT");
            c.setRequestProperty("Content-Type", "application/json");
            OutputStream os = c.getOutputStream();
            os.write(json.getBytes());
            os.flush();

            if (c.getResponseCode() == 200) {
                ResponseSalesOrderService r = m.readValue(c.getInputStream(),
                        ResponseSalesOrderService.class);
                req.setAttribute("message", "Item updated");
            } else {
                req.setAttribute("error", "Update failed: " + c.getResponseCode());
            }
            c.disconnect();
        }
        req.getRequestDispatcher("/orderitem-edit.jsp?orderId=" + orderId).forward(req, resp);
    }
}
