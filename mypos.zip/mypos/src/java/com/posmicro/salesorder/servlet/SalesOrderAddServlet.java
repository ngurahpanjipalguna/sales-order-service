/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.posmicro.salesorder.servlet;

/**
 *
 * @author ktanjana
 */


import com.fasterxml.jackson.databind.ObjectMapper;
import com.posmicro.salesorder.entity.SalesOrder;
import com.posmicro.salesorder.util.ResponseSalesOrderService;
import com.posmicro.util.AppConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

@WebServlet(name="SalesOrderAddServlet", urlPatterns={"/SalesOrderAddServlet"})
public class SalesOrderAddServlet extends HttpServlet {
    private static final String API_URL = AppConfig.getAPI_URL_SALES_ORDER();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        // basic fields
        SalesOrder o = new SalesOrder();
        o.setCustomerId(Long.parseLong(req.getParameter("customerId")));
        o.setCustomerName(req.getParameter("customerName"));
        // normalize totalAmount
        String ds = req.getParameter("decimalSeparator"),
               ts = req.getParameter("thousandSeparator");
        String amt = req.getParameter("totalAmount");
        
       if(amt==null || amt.length()<1){
           amt="0";
       }else{
           amt=amt.replace(ts,"").replace(ds,".");
       }
       
       
        double amount = 0.0D;
        
        try{
            amount=Double.parseDouble(amt);
            
        }catch(Exception exc){
            amount=0.0D;
        }
        
        o.setTotalAmount(amount);
        o.setStatus(req.getParameter("status"));
        o.setTenantId(1L);

        ObjectMapper m = new ObjectMapper();
        String json = m.writeValueAsString(o);

        try {
            URL url = new URL(API_URL);
            HttpURLConnection conn = (HttpURLConnection)url.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type","application/json");

            OutputStream os = conn.getOutputStream();
            os.write(json.getBytes()); os.flush();

            if(conn.getResponseCode()!=200){
                req.setAttribute("error","Failed to create order");
                conn.disconnect();
                req.getRequestDispatcher("/salesorder-add.jsp").forward(req,resp);
                return;
            }

            ResponseSalesOrderService r = m.readValue(conn.getInputStream(),
                                        ResponseSalesOrderService.class);
            resp.sendRedirect("SalesOrderListServlet?message=Order+created+ID+"+r.getSalesOrderId());
            conn.disconnect();
        } catch(Exception e){
            req.setAttribute("error","Error: "+e.getMessage());
            req.getRequestDispatcher("/salesorder-add.jsp").forward(req,resp);
        }
    }
}
