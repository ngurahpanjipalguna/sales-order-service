/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.posmicro.salesorder.servlet;

/**
 *
 * @author ktanjana
 */

import com.fasterxml.jackson.databind.ObjectMapper;
import com.posmicro.salesorder.entity.OrderItem;
import com.posmicro.salesorder.entity.SalesOrder;
import com.posmicro.salesorder.util.ResponseSalesOrderService;
import com.posmicro.util.AppConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

@WebServlet(name="OrderItemAddServlet", urlPatterns={"/OrderItemAddServlet"})
public class OrderItemAddServlet extends HttpServlet {
    private static final String API_URL = AppConfig.getAPI_URL_ORDER_ITEM();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        // forward to JSP
        req.getRequestDispatcher("/orderitem-add.jsp").forward(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        Long orderId    = Long.valueOf(req.getParameter("orderId"));
        OrderItem orderItem    = new OrderItem();
        SalesOrder so   = new SalesOrder();
        so.setOrderId(orderId);
        orderItem.setSalesOrder(so);
        orderItem.setProductId(Long.valueOf(req.getParameter("productId")));
        orderItem.setProductName(req.getParameter("productName"));
        orderItem.setProductCategory(req.getParameter("productCategory"));
        // normalize:
        String ts=req.getParameter("thousandSeparator"), ds=req.getParameter("decimalSeparator");
        String qty=req.getParameter("salesQuantity").replace(ts,"").replace(ds,".");
        String pr =req.getParameter("salesPrice").replace(ts,"").replace(ds,".");
        orderItem.setSalesQuantity(Float.parseFloat(qty));
        orderItem.setSalesPrice(Float.parseFloat(pr));
        orderItem.setTenantId(1L);

        ObjectMapper m = new ObjectMapper();
        String json = m.writeValueAsString(orderItem);

        try {
            URL url = new URL(API_URL+"/"+orderId);
            HttpURLConnection conn = (HttpURLConnection)url.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type","application/json");
            OutputStream os=conn.getOutputStream();
            os.write(json.getBytes()); os.flush();

            if(conn.getResponseCode()==200){
                // redirect back to list
                resp.sendRedirect("OrderItemListServlet?orderId="+orderId+"&message=Item+added");
            } else {
                req.setAttribute("error","Add failed: "+conn.getResponseCode());
                req.getRequestDispatcher("/orderitem-add.jsp").forward(req,resp);
            }
            conn.disconnect();
        } catch(Exception e){
            req.setAttribute("error","Error: "+e.getMessage());
            req.getRequestDispatcher("/orderitem-add.jsp").forward(req,resp);
        }
    }
}
