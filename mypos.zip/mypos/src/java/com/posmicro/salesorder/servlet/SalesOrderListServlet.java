/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.posmicro.salesorder.servlet;

/**
 *
 * @author ktanjana
 */


import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.posmicro.salesorder.entity.SalesOrder;
import com.posmicro.util.AppConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

@WebServlet(name="SalesOrderListServlet", urlPatterns={"/SalesOrderListServlet"})
public class SalesOrderListServlet extends HttpServlet {
    private static final String API_LIST_ALL = AppConfig.getAPI_URL_SALES_ORDER() + "/list/all";
    private static final String API_FIND    = AppConfig.getAPI_URL_SALES_ORDER() + "/find/";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String search = req.getParameter("search");
        String endpoint = (search!=null && !search.isBlank())
            ? API_FIND + search
            : API_LIST_ALL;

        URL url = new URL(endpoint);
        HttpURLConnection conn = (HttpURLConnection)url.openConnection();
        conn.setRequestProperty("Accept","application/json");
        
        try{
        if(conn.getResponseCode()!=200){
            req.setAttribute("error","Failed to load orders: HTTP "+conn.getResponseCode());
        } else {
            ObjectMapper m = new ObjectMapper();
            List<SalesOrder> list = m.readValue(
                new BufferedReader(new InputStreamReader(conn.getInputStream())),
                new TypeReference<List<SalesOrder>>(){}
            );
            req.setAttribute("orders",list);
        }
            conn.disconnect();
        }catch(Exception exc){
            req.setAttribute("error","Failed to connect orders: HTTP "+ exc.toString());
        }
        req.getRequestDispatcher("/salesorder-list.jsp").forward(req,resp);
    }
}
