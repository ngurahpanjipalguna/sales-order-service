/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.posmicro.salesorder.servlet;

/**
 *
 * @author ktanjana
 */


import com.fasterxml.jackson.databind.ObjectMapper;
import com.posmicro.salesorder.entity.SalesOrder;
import com.posmicro.salesorder.entity.OrderItem;
import com.posmicro.util.AppConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

@WebServlet(name="OrderItemListServlet", urlPatterns={"/OrderItemListServlet"})
public class OrderItemListServlet extends HttpServlet {
    private static final String API_URL = AppConfig.getAPI_URL_ORDER_ITEM();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        Long orderId = Long.valueOf(req.getParameter("orderId"));
        URL url = new URL(API_URL + "/list/by-order/" + orderId);
        HttpURLConnection conn = (HttpURLConnection)url.openConnection();
        conn.setRequestProperty("Accept","application/json");

        if(orderId!=0){
            SalesOrder salesOrder = new SalesOrder();
            salesOrder.setOrderId(orderId);
            req.setAttribute("order", salesOrder);
        }
        
        if(conn.getResponseCode()==200){
            OrderItem[] orderItem = new ObjectMapper()
                .readValue(conn.getInputStream(), OrderItem[].class);
            if(orderItem!=null && orderItem.length>0){
                req.setAttribute("items", orderItem);
            }
        } else {
            req.setAttribute("error","Failed to load items: "+conn.getResponseCode());
        }
        conn.disconnect();
        req.getRequestDispatcher("/orderitem-list.jsp").forward(req,resp);
    }
}
