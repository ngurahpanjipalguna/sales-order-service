/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.posmicro.product.servlet;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 *
 * @author ktanjana
 */
// ProductAddServlet.java

import com.fasterxml.jackson.databind.ObjectMapper;
import com.posmicro.product.entity.Product;
import com.posmicro.util.AppConfig;
import com.posmicro.product.util.ResponseProductService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

@WebServlet(name = "ProductAddServlet", urlPatterns = {"/ProductAddServlet"})
public class ProductAddServlet extends HttpServlet {

    private static String API_URL = AppConfig.getAPI_URL_PRODUCT();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String category = request.getParameter("category");

        String decimalSeparator = request.getParameter("decimalSeparator");
        String thousandSeparator = request.getParameter("thousandSeparator");

        String salesPriceStr = normalizeNumber(request.getParameter("salesPrice"), thousandSeparator, decimalSeparator);
        String stockLevelStr = normalizeNumber(request.getParameter("stockLevel"), thousandSeparator, decimalSeparator);
        String reorderLevelStr = normalizeNumber(request.getParameter("reorderLevel"), thousandSeparator, decimalSeparator);

        Float salesPrice = 0.0F;
        Float stockLevel = 0.0F;
        Float reorderLevel = 0.0F;
        
        try{
             salesPrice = Float.valueOf(salesPriceStr);
             stockLevel = Float.valueOf(stockLevelStr);
             reorderLevel = Float.valueOf(reorderLevelStr);
        }catch(Exception exc){
            request.setAttribute("error", "Failed to convert numbers: " + exc.toString() );
            request.getRequestDispatcher("product-add.jsp").forward(request, response);
        }
        

        Product product = new Product();
        product.setProductId(0L);
        product.setName(name);
        product.setCategory(category);
        product.setSalesPrice(salesPrice);
        product.setStockLevel(stockLevel);
        product.setReorderLevel(reorderLevel);
        product.setTenantId(1L);

        ObjectMapper mapper = new ObjectMapper();
        String json = mapper.writeValueAsString(product);

        try {
            URL url = new URL(API_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");

            OutputStream os = conn.getOutputStream();
            os.write(json.getBytes());
            os.flush();

            if (conn.getResponseCode() != 200) {
                request.setAttribute("error", "Failed to create product." + conn.getResponseMessage());
            } else {
                ResponseProductService result = mapper.readValue(conn.getInputStream(), ResponseProductService.class);
                request.setAttribute("message", "Product created successfully with ID: " + result.getProductId());
            }

            conn.disconnect();

        } catch (Exception e) {
            request.setAttribute("error", "Error: " + e.getMessage());
        }

        request.getRequestDispatcher("product-add.jsp").forward(request, response);
    }

    private String normalizeNumber(String input, String thousandSeparator, String decimalSeparator) {
        if (input == null) return "0";
        String normalized = input;
        if (!thousandSeparator.equals("")) {
            normalized = normalized.replace(thousandSeparator, "");
        }
        if (!decimalSeparator.equals(".")) {
            normalized = normalized.replace(decimalSeparator, ".");
        }
        return normalized;
    }
}