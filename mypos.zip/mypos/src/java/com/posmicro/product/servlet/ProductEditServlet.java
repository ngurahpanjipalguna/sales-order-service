/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.posmicro.product.servlet;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.posmicro.product.entity.Product;
import com.posmicro.product.util.ResponseProductService;
import com.posmicro.util.AppConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.util.regex.Pattern;

@WebServlet(name = "ProductEditServlet", urlPatterns = {"/ProductEditServlet"})
public class ProductEditServlet extends HttpServlet {

    private static String API_URL = AppConfig.getAPI_URL_PRODUCT();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        Long productId = Long.parseLong(request.getParameter("productId"));

        if ("delete".equals(action)) {
            handleDelete(request, response, productId);
            return;
        }

        String name = request.getParameter("name");
        String category = request.getParameter("category");

        String thousandSeparator = request.getParameter("thousandSeparator");
        String decimalSeparator = request.getParameter("decimalSeparator");
        
        
        if (thousandSeparator == null || thousandSeparator.length() < 1 || decimalSeparator == null || decimalSeparator.length() < 1) {
            NumberFormat nf = NumberFormat.getNumberInstance();
            nf.setMaximumFractionDigits(2);
            nf.setMinimumFractionDigits(0);
            char thousandSep = ',';  // sensible defaults in case nf isn't a DecimalFormat
            char decimalSep = '.';
            if (nf instanceof DecimalFormat) {
                DecimalFormatSymbols symbols = ((DecimalFormat) nf).getDecimalFormatSymbols();
                thousandSep = symbols.getGroupingSeparator();
                decimalSep = symbols.getDecimalSeparator();
            }
            thousandSeparator = Character.toString(thousandSep);
            decimalSeparator = Character.toString(decimalSep);
            
        }

        String salesPriceStr = normalizeNumber(request.getParameter("salesPrice"), thousandSeparator, decimalSeparator);
        String stockLevelStr = normalizeNumber(request.getParameter("stockLevel"), thousandSeparator, decimalSeparator);
        String reorderLevelStr = normalizeNumber(request.getParameter("reorderLevel"), thousandSeparator, decimalSeparator);

        Float salesPrice = 0.0F;
        Float stockLevel = 0.0F;
        Float reorderLevel = 0.0F;

        try {
            salesPrice = Float.valueOf(salesPriceStr);
            stockLevel = Float.valueOf(stockLevelStr);
            reorderLevel = Float.valueOf(reorderLevelStr);
        } catch (Exception exc) {
            request.setAttribute("error", "Failed to convert numbers: " + exc.toString());
            request.getRequestDispatcher("product-add.jsp").forward(request, response);
        }

        Product product = new Product();
        product.setProductId(productId);
        product.setName(name);
        product.setCategory(category);
        product.setSalesPrice(salesPrice);
        product.setStockLevel(stockLevel);
        product.setReorderLevel(reorderLevel);
        product.setTenantId(1L);

        ObjectMapper mapper = new ObjectMapper();
        String json = mapper.writeValueAsString(product);

        try {
            URL url = new URL(API_URL + "/" + productId);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("PUT");
            conn.setRequestProperty("Content-Type", "application/json");

            OutputStream os = conn.getOutputStream();
            os.write(json.getBytes());
            os.flush();

            if (conn.getResponseCode() != 200) {
                request.setAttribute("error", "Failed to update product.");
            } else {
                ResponseProductService result = mapper.readValue(conn.getInputStream(), ResponseProductService.class);
                request.setAttribute("message", result.getMessage() + ". Product ID=" + result.getProductId());
            }

            conn.disconnect();
        } catch (Exception e) {
            request.setAttribute("error", "Error: " + e.getMessage());
        }

        request.getRequestDispatcher("product-edit.jsp").forward(request, response);
    }

    private void handleDelete(HttpServletRequest request, HttpServletResponse response, Long productId)
            throws ServletException, IOException {
        try {
            URL url = new URL(API_URL + "/" + productId);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("DELETE");

            if (conn.getResponseCode() == 200) {
                // Redirect with message as query param
                response.sendRedirect("ProductListServlet?message=Product+with+ID+" + productId + "+deleted+successfully");
            } else {
                request.setAttribute("error", "Failed to delete product.");
                request.getRequestDispatcher("product-edit.jsp").forward(request, response);
            }

            conn.disconnect();
        } catch (Exception e) {
            request.setAttribute("error", "Error: " + e.getMessage());
            request.getRequestDispatcher("product-edit.jsp").forward(request, response);
        }
    }

    private String normalizeNumberX(String input, String thousandSeparator, String decimalSeparator) {
        if (input == null) {
            return "0";
        }
        String normalized = input;
        if (!thousandSeparator.equals("")) {
            normalized = normalized.replace(thousandSeparator, "");
        }
        if (!decimalSeparator.equals(".")) {
            normalized = normalized.replace(decimalSeparator, ".");
        }
        return normalized;
    }

    private String normalizeNumber(String input,
            String thousandSeparator,
            String decimalSeparator) {
        if (input == null || input.isBlank()) {
            return "0";
        }

        // 1) Trim
        String s = input.trim();

        // 2) Strip *all* grouping separators
        if (thousandSeparator != null && !thousandSeparator.isEmpty()) {
            s = s.replaceAll(Pattern.quote(thousandSeparator), "");
        }

        // 3) Replace the true decimal separator with “.”
        //    (only if it isn’t already “.”)
        if (decimalSeparator != null
                && !decimalSeparator.equals(".")
                && !decimalSeparator.isEmpty()) {
            s = s.replaceAll(Pattern.quote(decimalSeparator), ".");
        }

        // 4) If it now starts with “.”, prefix a zero
        if (s.startsWith(".")) {
            s = "0" + s;
        }
        // 5) If it ends with “.”, drop it
        if (s.endsWith(".")) {
            s = s.substring(0, s.length() - 1);
        }

        return s;
    }

}
