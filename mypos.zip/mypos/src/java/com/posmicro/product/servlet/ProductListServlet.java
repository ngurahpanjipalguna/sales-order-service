/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.posmicro.product.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import jakarta.servlet.http.*;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.posmicro.product.entity.Product;
import com.posmicro.util.AppConfig;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
/**
 *
 * @author ktanjana
 */

@WebServlet(name = "ProductListServlet", urlPatterns = {"/ProductListServlet"})
public class ProductListServlet extends HttpServlet {
    private static final String PRODUCT_API_ALL =  AppConfig.getAPI_URL_PRODUCT()+"/list/all";
    private static final String PRODUCT_API_FIND = AppConfig.getAPI_URL_PRODUCT()+"/find/";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String searchQuery = req.getParameter("search");
        String apiUrl;

        if (searchQuery != null && !searchQuery.trim().isEmpty()) {
            apiUrl = PRODUCT_API_FIND + URLEncoder.encode(searchQuery.trim(), StandardCharsets.UTF_8);
        } else {
            apiUrl = PRODUCT_API_ALL;
        }

        URL url = new URL(apiUrl);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Accept", "application/json");

        if (conn.getResponseCode() != 200) {
            req.setAttribute("error", "Failed to load products. API responded with status code: " + conn.getResponseCode());
            req.getRequestDispatcher("/product-list.jsp").forward(req, resp);
            return;
        }

        ObjectMapper mapper = new ObjectMapper();
        List<Product> productList = mapper.readValue(
                new InputStreamReader(conn.getInputStream()),
                new TypeReference<List<Product>>() {});

        conn.disconnect();

        req.setAttribute("products", productList);
        req.getRequestDispatcher("/product-list.jsp").forward(req, resp);
    }

    @Override
    public String getServletInfo() {
        return "Servlet to get list of products, optionally filtered by search parameter.";
    }
}

