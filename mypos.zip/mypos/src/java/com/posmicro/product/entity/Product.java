/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.posmicro.product.entity;

/**
 *
 * @author ktanjana
 */


public class Product {
   
    private Long productId;

    private String name;

  
    private String category;

    private Float salesPrice;

    private Float stockLevel;

    private Float reorderLevel;

    private Long tenantId;

    /**
     * @return the productId
     */
    public Long getProductId() {
        return productId;
    }

    /**
     * @param productId the productId to set
     */
    public void setProductId(Long productId) {
        this.productId = productId;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the category
     */
    public String getCategory() {
        return category;
    }

    /**
     * @param category the category to set
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     * @return the salesPrice
     */
    public Float getSalesPrice() {
        return salesPrice;
    }

    /**
     * @param salesPrice the salesPrice to set
     */
    public void setSalesPrice(Float salesPrice) {
        this.salesPrice = salesPrice;
    }

    /**
     * @return the stockLevel
     */
    public Float getStockLevel() {
        return stockLevel;
    }

    /**
     * @param stockLevel the stockLevel to set
     */
    public void setStockLevel(Float stockLevel) {
        this.stockLevel = stockLevel;
    }

    /**
     * @return the reorderLevel
     */
    public Float getReorderLevel() {
        return reorderLevel;
    }

    /**
     * @param reorderLevel the reorderLevel to set
     */
    public void setReorderLevel(Float reorderLevel) {
        this.reorderLevel = reorderLevel;
    }

    /**
     * @return the tenantId
     */
    public Long getTenantId() {
        return tenantId;
    }

    /**
     * @param tenantId the tenantId to set
     */
    public void setTenantId(Long tenantId) {
        this.tenantId = tenantId;
    }
    
}

